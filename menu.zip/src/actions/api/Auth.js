import { API } from './index'
// Auth
export const signIn = async (loginData) => API.post(`auth-admin`, loginData)
export const logOut = async (loginData) => API.post(`logout-user`, loginData)
export const customerLogin = async (data) => API.post(`customer-login`, data)
export const customerLogout = async (data) => API.post(`customer-logout`, data)
