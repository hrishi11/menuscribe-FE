import { Vendor } from '../api/routes'

export const getPackages = () => {
    return async dispatch => {
        try {
            const { data } = await Vendor.getPackages()
            return data
        } catch (error) {
            console.log('failed to signin')
        }
    }
}
export const getPackage = (id) => {
    return async dispatch => {
        try {
            const { data } = await Vendor.getPackage(id)
            return data
        } catch (error) {
            console.log('failed to signin')
        }
    }
}

export const addItem = (file, formData) => {
    return async dispatch => {
        try {
            const newData = new FormData();
            Object.entries(formData).forEach(([key, value]) => {
                newData.append(key, value);
            });
            newData.append('file', file);
            const { data } = await Vendor.addItem(newData)
            return data
        } catch (error) {
            console.log('failed to signin')
        }
    }
}

export const updateItem = (file, formData) => {
    return async dispatch => {
        try {
            const newData = new FormData();
            Object.entries(formData).forEach(([key, value]) => {
                newData.append(key, value);
            });
            newData.append('file', file);
            const { data } = await Vendor.updateItem(newData, formData.id)
            return data
        } catch (error) {
            console.log('failed to signin')
        }
    }
}

export const getItems = () => {
    return async dispatch => {
        try {
            const { data } = await Vendor.getItems()
            return data
        } catch (error) {
            console.log('failed to signin')
        }
    }
}

export const getItem = (id) => {
    return async dispatch => {
        try {
            const { data } = await Vendor.getItem(id)
            return data
        } catch (error) {
            console.log('failed to signin')
        }
    }
}

export const addDefaultItem = (formData) => {
    return async dispatch => {
        try {
            const { data } = await Vendor.addDefaultItem(formData)
            return data
        } catch (error) {
            console.log('failed to signin')
        }
    }
}

export const deleteDefaultItem = (id) => {
    return async dispatch => {
        try {
            const { data } = await Vendor.deleteDefaultItem(id)
            return data
        } catch (error) {
            console.log('failed to signin')
        }
    }
}

export const getCities = () => {
    return async dispatch => {
        try {
            const { data } = await Vendor.getCities()
            return data
        } catch (error) {
            console.log('failed to signin')
        }
    }
}

export const addPackageCity = (formData) => {
    return async dispatch => {
        try {
            const { data } = await Vendor.addPackageCity(formData)
            return data
        } catch (error) {
            console.log('failed to signin')
        }
    }
}

export const handledeleteCity = (id) => {
    return async dispatch => {
        try {
            const { data } = await Vendor.handledeleteCity(id)
            return data
        } catch (error) {
            console.log('failed to signin')
        }
    }
}

export const savePackage = (formData) => {
    return async dispatch => {
        try {
            const { data } = await Vendor.savePackage(formData)
            return data
        } catch (error) {
            console.log('failed to save package')
        }
    }
}

export const getDefaultItems = (id) => {
    return async dispatch => {
        try {
            const { data } = await Vendor.getDefaultItems(id)
            return data
        } catch (error) {
            console.log('failed to save package')
        }
    }
}

export const addItemToDay = (formData) => {
    return async dispatch => {
        try {
            const { data } = await Vendor.addItemToDay(formData)
            return data
        } catch (error) {
            console.log('failed to save package')
        }
    }
}

export const getCustomers = (formData) => {
    return async dispatch => {
        try {
            const { data } = await Vendor.getCustomers(formData)
            return data
        } catch (error) {
            console.log('failed to save package')
        }
    }
}

export const getCustomerOrders = (formData) => {
    return async dispatch => {
        try {
            const { data } = await Vendor.getCustomerOrders(formData)
            return data
        } catch (error) {
            console.log('failed to save package')
        }
    }
}

export const getOrderSummary = (formData) => {
    return async dispatch => {
        try {
            const { data } = await Vendor.getOrderSummary(formData)
            return data
        } catch (error) {
            console.log('failed to save package')
        }
    }
}

export const deactivatePackage = (id) => {
    return async dispatch => {
        try {
            const { data } = await Vendor.deactivatePackage(id)
            return data
        } catch (error) {
            console.log('failed to save package')
        }
    }
}

export const setPaymentStatus = (formData) => {
    return async dispatch => {
        try {
            const { data } = await Vendor.setPaymentStatus(formData)
            return data
        } catch (error) {
            console.log('failed to save package')
        }
    }
}