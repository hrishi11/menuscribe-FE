import { customerActions } from "./CustomerSlice"
import { Customer } from '../api/routes'
import { adjustData } from "../../utils/Helper"

export const checkExistingUser = (phone) => {
    return async dispatch => {
        try {
            const { data } = await Customer.checkExistingUser(phone)
            return data
        } catch (error) {
            console.log('failed to signin')
        }
    }
}

export const saveCustomer = (formData) => {
    return async dispatch => {
        try {
            const { data } = await Customer.saveCustomer(formData)
            return data
        } catch (error) {
            console.log('failed to signin')
        }
    }
}

export const setPackagesData = (packageData) => {
    return async dispatch => {
        try {
            const newData = adjustData(packageData);
            const { data } = await Customer.savePackages(newData)
            dispatch(customerActions.selectedPackages(newData))
        //    return data
        } catch (error) {
            console.log('error', error)
            console.log('failed to save package')
        }
    }
}

export const getCustomer = (id) => {
    return async dispatch => {
        try {
            const { data } = await Customer.getCustomer(id)
            return data
        } catch (error) {
            console.log('failed to get customer')
        }
    }
}

export const getCustomerByVC = (id) => {
    return async dispatch => {
        try {
            const { data } = await Customer.getCustomerByVC(id)
            return data
        } catch (error) {
            console.log('failed to get customer')
        }
    }
}

export const updateCustomerPassword = (formData) => {
    return async dispatch => {
        try {
            const { data } = await Customer.updateCustomerPassword(formData)
            return data
        } catch (error) {
            console.log('failed to get customer')
        }
    }
}

export const checkVerificationPin = (formData) => {
    return async dispatch => {
        try {
            const { data } = await Customer.checkVerificationPin(formData)
            return data
        } catch (error) {
            console.log('failed to get customer')
        }
    }
}

export const updateCustomer = (formData) => {
    return async dispatch => {
        try {
            const { data } = await Customer.updateCustomer(formData)
            return data
        } catch (error) {
            console.log('failed to get customer')
        }
    }
}


export const getUserPackages = (formData) => {
    return async dispatch => {
        try {
            const { data } = await Customer.getUserPackages({ids: formData})
            return data
        } catch (error) {
            console.log('failed to get customer')
        }
    }
}

export const getCustomerPackages = (id) => {
    return async dispatch => {
        try {
            const { data } = await Customer.getCustomerPackages(id)
            return data
        } catch (error) {
            console.log('failed to get customer')
        }
    }
}

export const saveCustomerOrder = (formData) => {
    return async dispatch => {
        try {
            const { data } = await Customer.saveCustomerOrder({ids: formData})
            return data
        } catch (error) {
            console.log('failed to get customer')
        }
    }
}


export const cancelCustomerOrder = (formData) => {
    return async dispatch => {
        try {
            const { data } = await Customer.cancelCustomerOrder(formData)
            return data
        } catch (error) {
            console.log('failed to get customer')
        }
    }
}

export const getCustomerAddress = (id) => {
    return async dispatch => {
        try {
            const { data } = await Customer.getCustomerAddress(id)
            return data
        } catch (error) {
            console.log('failed to get customer')
        }
    }
}

export const updateCustomerAddress = (formData) => {
    return async dispatch => {
        try {
            const { data } = await Customer.updateCustomerAddress(formData)
            return data
        } catch (error) {
            console.log('failed to get address ')
        }
    }
}

export const deleteCustomerAddress = (id) => {
    return async dispatch => {
        try {
            const { data } = await Customer.deleteCustomerAddress(id)
            return data
        } catch (error) {
            console.log('failed to get address ')
        }
    }
}

