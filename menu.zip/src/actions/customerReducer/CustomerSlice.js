import { createSlice } from "@reduxjs/toolkit"
import { adjustData } from "../../utils/Helper";

const customerSlice = createSlice({
    name: 'customer',
    initialState: { customerData: [], customerSelectedPackages: [] },
    reducers: {
        signIn(state, action) {
            state.customerData = []
        },
        selectedPackages(state, action) {
            //console.log(action)
            

            state.customerSelectedPackages = action.payload;
        },
    }
})

export const customerActions = customerSlice.actions
export default customerSlice