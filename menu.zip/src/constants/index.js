//local
//export const API_URL = 'http://localhost:5000/api/'
// live
export const API_URL = 'https://app.menuscribe.com/api/'