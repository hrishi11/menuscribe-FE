import { CButton, CCol, CNav, CNavItem, CNavLink, CRow, CTabContent, CTabPane } from "@coreui/react";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { getCustomerPackages, deleteCustomerAddress } from '../../actions/customerReducer/CustomerActions'
import { useNavigate } from "react-router-dom";
import { customerLogout } from '../../actions/authReducer/AuthActions'
import { formatTime } from "../../utils/Helper";
import CancelConfirm from "../../components/app/modals/CancelConfirm";
import CustomerAddress from "../../components/app/modals/CustomerAddress";
import { Toast } from "../../components/app/Toast";

const DashboardCustomer = () => {
    const [activeKey, setActiveKey] = useState(1);
    const [customerPackages, setCustomerPackages] = useState();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const vendorData = JSON.parse(localStorage.getItem('menuScribe'));
    const [vendorSetting, setVendorSetting] = useState();
    const [showConfirmModal, setShowConfirmModal] = useState(false)
    const [cancelId, setCancelId] = useState('');
    const [customerId, setCustomerId] = useState('');
    const [updateTrigger, setUpdateTrigger] = useState(false);
    const [customerAddresses, setCustomerAddresses] = useState([]);
    const [showAddressModal, setShowAddressModal] = useState(false);
    const [addressId, setAddressId] = useState('');

    const handleMenuButton = () => {
        navigate('/menu')
    }
    const handleCancelButton = (id) => {
        setCancelId(id)
        setShowConfirmModal(true)
    }
    const handleAddressButton = (address) => {
        var googleMapsUrl = 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(address);
        window.open(googleMapsUrl, '_blank');
    }

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [userResponse] = await Promise.all([
                    dispatch(getCustomerPackages(vendorData.id)),
                ]);
                setCustomerPackages(userResponse.data.results)
                setVendorSetting(userResponse.data.vendorSetting)
                setCustomerAddresses(userResponse.data.CustomerAddress)
                setCustomerId(vendorData.id)
            } catch (error) {
                console.error("Error fetching packages:", error);
            }
        };
        fetchData();
    }, [dispatch, vendorData.id, updateTrigger]);

    const handleDeleteAddress = async (id) => {
        const response = await dispatch(deleteCustomerAddress(id));
        setUpdateTrigger((prev) => !prev);
        if (response && response.success) {
            Toast({ message: 'Item deleted successfully.', type: 'success' });
        }
    }

    const handleLogout = async () => {
        await dispatch(customerLogout());
        navigate('/login')
    }

    const handleAddPackage = () => {
        navigate('/customer')
    }

    const handleAddress = (id) => {
        setAddressId(id)
        setShowAddressModal(true)
    }

    return (
        <div className='mb-3 d-flex justify-content-center'>
            <div className='col-md-6 col-12 d-block box px-2 py-2 bg-red'>
                <div className="d-flex justify-content-between">
                    <h1 className="h4 fw-bold text-info text-center text-white">My Packages</h1>
                    <CButton
                        className="simple-button"
                        color="secondary rounded my-1 fw-bold"
                        onClick={handleLogout}
                    >Logout</CButton>
                </div>
                <CNav variant="tabs" role="tablist">
                    <CNavItem role="presentation">
                        <CNavLink
                            active={activeKey === 1}
                            component="button"
                            role="tab"
                            aria-controls="home-tab-pane"
                            aria-selected={activeKey === 1}
                            onClick={() => setActiveKey(1)}
                        >
                            Packages
                        </CNavLink>
                    </CNavItem>
                    <CNavItem role="presentation">
                        <CNavLink
                            active={activeKey === 2}
                            component="button"
                            role="tab"
                            aria-controls="profile-tab-pane"
                            aria-selected={activeKey === 2}
                            onClick={() => setActiveKey(2)}
                        >
                            Profile
                        </CNavLink>
                    </CNavItem>
                    <CNavItem role="presentation">
                        <CNavLink
                            active={activeKey === 3}
                            component="button"
                            role="tab"
                            aria-controls="contact-tab-pane"
                            aria-selected={activeKey === 3}
                            onClick={() => setActiveKey(3)}
                        >
                            Contact
                        </CNavLink>
                    </CNavItem>
                    <CNavItem role="presentation">
                        <CNavLink
                            active={activeKey === 4}
                            component="button"
                            role="tab"
                            aria-controls="disabled-tab-pane"
                            aria-selected={activeKey === 4}
                            onClick={() => setActiveKey(4)}
                        >
                            Disabled
                        </CNavLink>
                    </CNavItem>
                </CNav>
                <CTabContent>
                    <CTabPane role="tabpanel" aria-labelledby="home-tab-pane" visible={activeKey === 1}>
                        <CRow>
                            <CCol className="mt-1">
                                <CButton
                                    className="float-end simple-button text-white"
                                    color="info"
                                    onClick={handleAddPackage}
                                >Add Package</CButton>
                            </CCol>
                        </CRow>
                        <CRow>
                            <CCol className="mt-2">
                                {customerPackages && customerPackages.map((item) => (
                                    item.VendorPackage &&
                                    <div className="bg-white px-2 py-2 mb-4 mx-3 border-1 border-dark rounded" key={item.id}>
                                        <div className="d-flex justify-content-between">
                                            <h5>Taj Mahal Indian Restaurant</h5>
                                            <i className="text-danger">{`${item.VendorPackage.delivery && 'Delivery'}`}</i>
                                        </div>
                                        <CRow>
                                            <CCol>
                                                <h6>{item.VendorPackage.package_name}</h6>
                                                {item.VendorPackage.VendorPackageDefaultItems.map((ditem) => (
                                                    <p key={ditem.id}>{ditem.item_name}</p>
                                                ))}
                                            </CCol>
                                            <CCol className="text-justify text-end">
                                                {item.frequency === 'daily' && (
                                                    <p className="text-gray">${item.VendorPackage.price_daily}</p>
                                                )}
                                                {item.frequency === 'weekly' && (
                                                    <p className="text-gray">${item.VendorPackage.price_weekly}</p>
                                                )}
                                                {item.frequency === 'monthly' && (
                                                    <p className="text-gray">${item.VendorPackage.price_monthly}</p>
                                                )}
                                                {item.frequency === 'daily' && (
                                                    <p className="text-gray">Single Day</p>
                                                )}
                                                {item.frequency === 'weekly' && (
                                                    <p className="text-gray">5 Days</p>
                                                )}
                                                {item.frequency === 'monthly' && (
                                                    <p className="text-gray">20 Days</p>
                                                )}
                                                <p className="text-gray">Delivery Time</p>
                                                <p className="text-gray">{`${formatTime(item.VendorPackage.delivery_schedule_start)} - ${formatTime(item.VendorPackage.delivery_schedule_end)}`}</p>
                                            </CCol>
                                        </CRow>
                                        <CRow>
                                            <CCol>
                                                {vendorSetting.menu_option && (
                                                    <CButton color="info" className="mx-1 text-white rounded-0" onClick={handleMenuButton}>Menu</CButton>
                                                )}
                                                {vendorSetting.cancel_option && (
                                                    <CButton color="info" className="mx-1 text-white rounded-0" onClick={() => handleCancelButton(item.package_id)}>Cancel</CButton>
                                                )}
                                                {vendorSetting.menu_option && (
                                                    <CButton color="info" className="mx-1 text-white rounded-0" onClick={() => handleAddressButton(item.UserCustomer.address_1)}>Address</CButton>
                                                )}
                                            </CCol>
                                        </CRow>
                                    </div>
                                ))}
                            </CCol>
                        </CRow>
                        <CRow className="d-flex justify-content-center">
                            <div className="col-10 bg-white rounded">
                                <p className="text-center">Add your delivery addresses below</p>
                                {customerAddresses && customerAddresses.map((address) => (
                                    <CRow key={address.id}>
                                        <div className="d-flex justify-content-center my-1 py-1 border-bottom">
                                            <p className="me-3">{`${address.address} ${address.postal} ${address.CitiesAll && address.CitiesAll.city}`}</p>
                                            <CButton color="info" className="mx-1 text-white btn-sm" onClick={() => handleAddress(address.id)}>Edit</CButton>
                                            <CButton color="danger" className="mx-1 text-white btn-sm" onClick={() => handleDeleteAddress(address.id)}>X</CButton>
                                        </div>
                                    </CRow>
                                ))}
                                <div className="d-flex justify-content-center my-1">
                                    <CButton color="info" className="mx-1 text-white rounded-0 btn-sm" onClick={() => handleAddress(0)}>Add Address</CButton>
                                </div>
                            </div>
                        </CRow>
                    </CTabPane>
                    <CTabPane role="tabpanel" aria-labelledby="profile-tab-pane" visible={activeKey === 2}>
                        Food
                    </CTabPane>
                    <CTabPane role="tabpanel" aria-labelledby="contact-tab-pane" visible={activeKey === 3}>
                        Etsy
                    </CTabPane>
                    <CTabPane role="tabpanel" aria-labelledby="disabled-tab-pane" visible={activeKey === 3}>
                        Etsy
                    </CTabPane>
                </CTabContent>
            </div>
            <CRow>
                <CancelConfirm
                    showConfirmModal={showConfirmModal}
                    setShowConfirmModal={setShowConfirmModal}
                    packageId={cancelId}
                    customerId={customerId}
                    updateTrigger={updateTrigger}
                    setUpdateTrigger={setUpdateTrigger}
                />
                <CustomerAddress
                    showAddressModal={showAddressModal}
                    setShowAddressModal={setShowAddressModal}
                    addressId={addressId}
                    customerId={customerId}
                    setUpdateTrigger={setUpdateTrigger}
                />
            </CRow>
        </div >
    );
}

export default DashboardCustomer;