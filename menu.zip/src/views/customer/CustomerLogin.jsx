import { CButton, CCol, CForm, CFormInput, CFormLabel, CRow } from "@coreui/react";
import { useEffect, useState } from "react";
import {
    customerLogin
} from '../../actions/authReducer/AuthActions'

import { useDispatch } from "react-redux";
import { useNavigate } from 'react-router-dom'

const CustomerLogin = () => {
    const [userData, setUserData] = useState();
    const [validated, setValidated] = useState(false)
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const [formData, setFormData] = useState({
    });


    // useEffect(() => {
    //     const fetchData = async () => {
    //         try {
    //             const [userResponse] = await Promise.all([
    //                 dispatch(getCustomer(3)),
    //             ]);
    //             setUserData(userResponse.data)
    //             setFormData(userResponse.data);
    //         } catch (error) {
    //             console.error("Error fetching packages:", error);
    //         }
    //     };
    //     fetchData();
    // }, [dispatch]);

    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        const form = event.currentTarget
        if (form.checkValidity() === false) {
            event.stopPropagation()
            setValidated(true)
        } else {
            const response = await dispatch(customerLogin(formData));
            if (response && response.success) {
                navigate('/customer-dashboard')
            }
        }
    }

    return (
        <div className='mb-3 d-flex justify-content-center'>
            <div className='col-md-6 col-12 d-block box px-2 py-2'>
                <div>
                    <h4 className="mt-5 text-center text-info fw-bold text-uppercase">Login</h4>
                    <p className="h5 text-center">Please login using your phone number oe email address.</p>
                    <CForm
                        className="row g-3 needs-validation"
                        noValidate
                        validated={validated}
                        onSubmit={handleSubmit}
                    >
                        <CRow>
                            <CCol className="mt-3">
                                <CFormLabel>Email / Phone (without country Code)</CFormLabel>
                                <CFormInput
                                    name="email"
                                    type="text"
                                    placeholder="Email / Phone"
                                    aria-label="email"
                                    id="validationCustom01"
                                    value={formData.email}
                                    onChange={handleInputChange}
                                    required
                                />
                            </CCol>
                        </CRow>
                        <CRow>
                            <CCol className="mt-3">
                                <CFormLabel>Password</CFormLabel>
                                <CFormInput
                                    name="password"
                                    type="password"
                                    placeholder="Password"
                                    aria-label="Password"
                                    id="validationCustom01"
                                    value={formData.password}
                                    onChange={handleInputChange}
                                    required
                                />
                            </CCol>
                        </CRow>
                        <CRow>
                            <CCol>
                                <CButton type="submit" className="mt-3 px-5 w-100 text-white" color="info">Login</CButton>
                            </CCol>
                        </CRow>
                    </CForm>
                </div>
            </div>
        </div>
    );
}

export default CustomerLogin;