import {
    CButton,
    CCard,
    CCardBody,
    CCardHeader,
    CCol,
    CForm,
    CFormInput,
    CFormLabel,
    CFormSelect,
    CFormTextarea,
    CRow,
} from '@coreui/react'

import { useDispatch } from 'react-redux';
import { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { checkExistingUser, saveCustomer } from '../../actions/customerReducer/CustomerActions'
import { getCities, getPackages } from '../../actions/vendorReducers/VendorActions'

import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { Toast } from '../../components/app/Toast';
import { getDateFromString } from '../../utils/Helper';
import { parseISO } from 'date-fns';

const AddCustomer = () => {
    const [formDisabled, setFormDisabled] = useState(true);
    const [validated, setValidated] = useState(false)
    const [citiesData, setCitiesData] = useState();
    const [packages, setPackages] = useState();
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        first_name: '',
        last_name: '',
        email: '',
        address: '',
        delivery_instruction: '',
        postal_code: '',
        city: '',
        package: '',
        package_start: ''
    });

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [citiesResponse, packagesResponse] = await Promise.all([
                    dispatch(getCities()),
                    dispatch(getPackages())
                ]);
                setCitiesData(citiesResponse.data);
                setPackages(packagesResponse.data)
            } catch (error) {
                console.error("Error fetching packages:", error);
            }
        };
        fetchData();
    }, [dispatch]);

    const handleSubmit = async (event) => {
        event.preventDefault();
        const form = event.currentTarget
        if (form.checkValidity() === false) {
            event.stopPropagation()
            setValidated(true)
        } else {
            const response = await dispatch(saveCustomer(formData));
            if (response && response.success) {
                navigate('/customers')
                Toast({ message: 'Customer added successfully.', type: 'success' });
            } else {
                Toast({ message: 'Customer did not added there is some problem.', type: 'error' });
            }
        }

    }

    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const checkExisting = async () => {
        const response = await dispatch(checkExistingUser(formData));
        if (response.status === false) {
            setFormDisabled(false);
            Toast({ message: 'Number do not exist.', type: 'success' });
        } else {
            setFormDisabled(true)
            setFormData((prevData) => ({
                ...prevData,
                ...response.data,
                address: response.data?.address_1 || '',
                delivery_instruction: response.data?.VendorCustomerLink?.delivery_instructions || '',
                package: response.data?.CustomerPackage?.package_id || '',
                start_date: parseISO(response.data?.CustomerPackage?.start_date) || '',
            }));
            Toast({ message: 'Number already exist.', type: 'success' });
        }
    }

    const setDate = (name, date) => {
        setFormData((prevData) => ({
            ...prevData,
            [name]: date,
        }));
    }

    console.log(formData)

    return (
        <CRow>
            <CCol xs={8}>
                <CCard className="mb-4">
                    {/* <CCardHeader>
                        <strong>Add Customer</strong>
                    </CCardHeader> */}
                    <CCardBody>
                        <div className="mb-3">
                            <CFormLabel htmlFor="exampleFormControlInput1">Phone</CFormLabel>
                            <div className='d-flex'>
                                <div className='me-2'><h4>+1</h4></div>
                                <div className="w-100">
                                    <CFormInput
                                        type="number"
                                        name="phone"
                                        placeholder="12345678"
                                        value={formData.phone}
                                        onChange={handleInputChange}
                                        required
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="col-auto text-center">
                            <CButton type="button" className="mb-3" color='info' onClick={() => checkExisting()}>
                                Add as my customer
                            </CButton>
                        </div>
                        <CForm
                            className="row g-3 needs-validation"
                            noValidate
                            validated={validated}
                            onSubmit={handleSubmit}
                        >
                            <div className="mb-3">
                                <CRow>
                                    <CCol xs>
                                        <CFormLabel htmlFor="First Name">First Name</CFormLabel>
                                        <CFormInput
                                            name="first_name"
                                            placeholder="First name"
                                            aria-label="First name"
                                            id="validationCustom01"
                                            value={formData.first_name}
                                            onChange={handleInputChange}
                                            required
                                            disabled={formDisabled}
                                        />
                                    </CCol>
                                    <CCol xs>
                                        <CFormLabel htmlFor="Last Name">Last Name</CFormLabel>
                                        <CFormInput
                                            name="last_name"
                                            placeholder="Last name"
                                            aria-label="Last name"
                                            id="validationCustom02"
                                            value={formData.last_name}
                                            onChange={handleInputChange}
                                            required
                                            disabled={formDisabled}

                                        />
                                    </CCol>
                                </CRow>
                            </div>
                            <div className="mb-3">
                                <CCol xs>
                                    <CFormLabel htmlFor="Email">Email</CFormLabel>
                                    <CFormInput
                                        name="email"
                                        placeholder="Email"
                                        aria-label="Email"
                                        id="validationCustom03"
                                        value={formData.email}
                                        onChange={handleInputChange}
                                        required
                                        disabled={formDisabled}

                                    />
                                </CCol>
                            </div>
                            <div className="mb-3">
                                <CCol xs>
                                    <CFormLabel htmlFor="Address">Address (Line 1)</CFormLabel>
                                    <CFormInput
                                        name="address"
                                        placeholder="Address"
                                        aria-label="Address"
                                        id="validationCustom04"
                                        value={formData.address}
                                        onChange={handleInputChange}
                                        required
                                        disabled={formDisabled}

                                    />
                                </CCol>
                            </div>
                            <div className="mb-3">
                                <CCol xs>
                                    <CFormLabel htmlFor="delivery_instruction">Delivery Instructions (optional)</CFormLabel>
                                    <CFormInput
                                        name="delivery_instruction"
                                        placeholder="mike.jones@hotmail.com"
                                        aria-label="delivery_instruction"
                                        id="validationCustom05"
                                        value={formData.delivery_instruction}
                                        onChange={handleInputChange}
                                        required
                                        disabled={formDisabled}

                                    />
                                </CCol>
                            </div>
                            <div className="mb-3">
                                <CCol xs>
                                    <CFormLabel htmlFor="postal_code">Postal Code</CFormLabel>
                                    <CFormInput
                                        name='postal_code'
                                        placeholder="LSS 2H6"
                                        aria-label="postal_code"
                                        id="validationCustom06"
                                        value={formData.postal_code}
                                        onChange={handleInputChange}
                                        required
                                        disabled={formDisabled}

                                    />
                                </CCol>
                            </div>
                            <div className="mb-3">
                                <CCol xs>
                                    <CFormLabel htmlFor="city">City</CFormLabel>
                                    <CFormSelect
                                        name="city"
                                        aria-label="Default select example"
                                        id="validationCustom07"
                                        value={formData.city}
                                        onChange={handleInputChange}
                                        required
                                        disabled={formDisabled}

                                    >
                                        {citiesData && citiesData.map((item) => (
                                            <option key={item.id} value={item.id}>{item.city}</option>
                                        ))}
                                    </CFormSelect>
                                </CCol>
                            </div>
                            <div className="mb-3">
                                <CCard className="mb-4">
                                    <CCardHeader className='text-center'>
                                        <strong>Add Packages</strong>
                                    </CCardHeader>
                                    <CCardBody>
                                        <CRow>
                                            <CCol xs>
                                                <CFormLabel htmlFor="postal_code">Assign Package</CFormLabel>
                                                <CFormSelect
                                                    aria-label="Default select example"
                                                    name='package'
                                                    disabled={formDisabled}
                                                    id="validationCustom08"
                                                    onChange={handleInputChange}
                                                    value={formData.package}
                                                >
                                                    <option>Select Package</option>
                                                    {packages && packages.map((item) => (
                                                        <option value={item.id} key={item.id}>{item.package_name}</option>
                                                    ))}
                                                </CFormSelect>
                                            </CCol>
                                            <CCol xs>
                                                <CFormLabel htmlFor="postal_code">Package Start Date</CFormLabel>
                                                <div>
                                                    <DatePicker
                                                        selected={formData.start_date}
                                                        onChange={(date) => setDate('start_date', date)}
                                                        dateFormat="yyyy-MM-dd"
                                                        className="form-control w-100"
                                                        value={formData.start_date}
                                                        disabled={formDisabled}
                                                    />
                                                </div>
                                            </CCol>
                                        </CRow>
                                        {/* <CRow>
                                            <CCol xs>
                                                <CFormLabel htmlFor="postal_code">Assign Package</CFormLabel>
                                                <CFormSelect
                                                    aria-label="Default select example"
                                                    disabled={formDisabled}
                                                    name="assign_package"
                                                    id="validationCustom09"
                                                >
                                                    <option>Silver Package</option>
                                                    <option value="1">One</option>
                                                    <option value="2">Two</option>
                                                    <option value="3">Three</option>
                                                </CFormSelect>
                                            </CCol>
                                            <CCol xs>
                                                <CFormLabel htmlFor="postal_code">Package Start Date</CFormLabel>
                                                <div>
                                                    <DatePicker
                                                        selected={formData.silver_start_date}
                                                        onChange={(date) => setDate('silver_start_date', date)}
                                                        dateFormat="yyyy-MM-dd"
                                                        className="form-control w-100"
                                                    />
                                                </div>
                                            </CCol>
                                        </CRow> */}
                                        {/* <CCol xs>
                                            <p className='text-center mt-3 text-info'>Add Another Package</p>
                                        </CCol> */}

                                    </CCardBody>
                                </CCard>
                            </div>
                            <div className="col-auto">
                                <CButton
                                    type="submit"
                                    className="mb-3"
                                    color='secondary'
                                    // disabled={formDisabled}
                                >
                                    Save
                                </CButton>
                            </div>
                        </CForm>
                    </CCardBody>
                </CCard>
            </CCol>
        </CRow>
    )
}

export default AddCustomer
