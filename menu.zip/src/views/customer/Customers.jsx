import { CButton, CCard, CCardBody, CCardHeader, CCol, CFormSelect, CRow } from "@coreui/react";
import { getCustomers, setPaymentStatus } from '../../actions/vendorReducers/VendorActions';
import { useEffect, useState } from "react";
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { formatDate, getDateFromString } from "../../utils/Helper";
import { Toast } from "../../components/app/Toast";

const Customers = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [customersData, setCustomersData] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await dispatch(getCustomers());
                setCustomersData(response.data);
            } catch (error) {
                console.error("Error fetching customers:", error);
            }
        };
        fetchData();
    }, [dispatch]);

    const handlePaymentStatus = async (userId, customer_package, value) => {
        if (!customer_package) {
            return Toast({ message: 'There is no package added to this user.', type: 'error' });
        }
        const response = await dispatch(setPaymentStatus({ value, userId, customer_package }));
        if (response.success) {
            Toast({ message: 'Payment status updated.', type: 'success' });
        } else {
            Toast({ message: 'There is some error while updating payment status.', type: 'error' });
        }
    }

    const handleAddCustomer = () => {
        navigate(`/add-customer`);
    }
    return (
        <CRow>
            <CCol>
                <CCard className="mb-4">
                    <CCardHeader>
                        <div className="d-flex justify-content-between">
                            <h3>Customers</h3>
                            <CButton className="float-end text-white" color="info" onClick={handleAddCustomer}>Add Customer</CButton>
                        </div>
                    </CCardHeader>
                    <CCardBody>
                        <table className="table striped">
                            <thead>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Package</th>
                                <th>Added on</th>
                                <th>Status</th>
                            </thead>
                            <tbody>
                                {customersData && customersData.map((item, index) => (
                                    <tr key={index}>
                                        <td>{item.first_name}</td>
                                        <td>{item.last_name}</td>
                                        <td>{item.email}</td>
                                        <td>{item.phone}</td>
                                        <td>{item.CustomerPackage && item?.CustomerPackage?.VendorPackage?.package_name}</td>
                                        <td>{getDateFromString(item.created_date)}</td>
                                        <td>
                                            <CFormSelect
                                                name="payment_status"
                                                value={item.payment_status}
                                                onChange={(e) => handlePaymentStatus(item.id, item?.CustomerPackage?.id, e.target.value)}
                                            >
                                                <option value="1">Paid</option>
                                                <option value="0">Un-Paid</option>
                                            </CFormSelect>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </CCardBody>
                </CCard>
            </CCol>
        </CRow>
    );
}

export default Customers;