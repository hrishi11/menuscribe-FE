import React, { useEffect, useState } from 'react';
import { getPackages } from '../../actions/vendorReducers/VendorActions'
import { setPackagesData } from '../../actions/customerReducer/CustomerActions'
import { useDispatch } from "react-redux";
import { CButton, CCard, CCardBody, CCardHeader, CCol, CFormInput, CFormSelect, CRow } from '@coreui/react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { getCurrentDate, getDateFromString } from '../../utils/Helper';
import { useNavigate } from 'react-router-dom';

const Customer = () => {
    const [packages, setPackages] = useState();
    const [selectedPackages, setSelectedPackages] = useState({
    });
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [products, setProducts] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [packagesResponse] = await Promise.all([
                    dispatch(getPackages())
                ]);
                setPackages(packagesResponse.data)
            } catch (error) {
                console.error("Error fetching packages:", error);
            }
        };
        fetchData();
    }, [dispatch]);

    const handleAddPackage = async (id) => {
        const isIdAlreadyAdded = products.some((product) => product.id === id);
        if (!isIdAlreadyAdded) {
            setProducts([...products, { id, content: <SelectedPackage key={id} id={id} /> }]);
        }

        setSelectedPackages((prevData) => ({
            ...prevData,
            [[`frequency_` + id]]: 'daily',
            [[`quantity_` + id]]: '1',
            [[`packagename_` + id]]: '',
            [[`date_` + id]]: getCurrentDate(),
        }));
    }

    const handleChange = (event) => {
        const { name, value } = event.target;
        setSelectedPackages((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };

    const setDate = (name, date) => {
        setSelectedPackages((prevData) => ({
            ...prevData,
            [name]: getDateFromString(date),
        }));
    }
    const handlePackagesData = async () => {
        console.log(selectedPackages)
        await dispatch(setPackagesData(selectedPackages))
        navigate('/order-confirmation')
    }

    const removePackage = (id) => {
        setProducts((prevProducts) => prevProducts.filter((product) => product.id !== id));
        setSelectedPackages((prevData) => ({
            ...prevData,
            [[`frequency_` + id]]: '',
            [[`quantity_` + id]]: '',
            [[`packagename_` + id]]: '',
            [[`date_` + id]]: '',
        }));
    }

    const handleDashboard = () => {
        navigate('/customer-dashboard')
    }

    const SelectedPackage = ({ id }) => (
        <div className='mb-3 d-flex justify-content-center'>
            <div className='col-md-6 col-12 d-block box px-2 py-2'>
                <div className='d-flex justify-content-between'>
                    <p>Package Name</p>
                    <p className='cursor-pointer text-info' onClick={() => removePackage(id)}>Remove</p>
                </div>
                <CFormSelect
                    className='mt-2'
                    name={`frequency_${id}`}
                    onChange={handleChange}
                >
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="montly">Monthly</option>
                </CFormSelect>
                <CFormInput
                    className='mt-2'
                    name={`packagename_${id}`}
                    placeholder='Package Name'
                    onChange={handleChange}
                />
                <CRow>
                    <CCol>
                        <DatePicker
                            selected={new Date()}
                            onChange={(date) => setDate(`date_${id}`, date)}
                            dateFormat="yyyy-MM-dd"
                            className="form-control w-100 mt-2"
                            name={`date_${id}`}
                        />
                    </CCol>
                    <CCol>
                        <CFormSelect
                            className='mt-2'
                            name={`quantity_${id}`}
                            onChange={handleChange}
                        >
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                        </CFormSelect>
                    </CCol>
                </CRow>
                <p className='text-danger text-center'>4 Weekly Deliveries for $240 total</p>
            </div>
        </div>
    );

    return (
        <div className='container'>
            <div className='d-flex justify-content-between'>
                <h1>Customer</h1>
                <CRow>
                    <CCol className="mt-1">
                        <CButton
                            className="float-end simple-button text-white"
                            color="info"
                            onClick={handleDashboard}
                        >Dashboard</CButton>
                    </CCol>
                </CRow>
            </div>
            <CRow>
                <CCol></CCol>
                <CCol>
                    <CCard className="mb-4 background-gray">
                        <CCardHeader>
                            <strong>Select Your Package</strong>
                        </CCardHeader>
                        <CCardBody>
                            <div className="mb-3">
                                <div className="row flex-nowrap overflow-auto">
                                    {packages && packages.map((item, index) => (
                                        <div className="product-box position-relative" key={index}>
                                            <div className="py-3 mx-2 text-center">
                                                <h5 className='fw-bold'>{item.package_name}</h5>
                                                {item.VendorPackageDefaultItems.map((ditem, index) => (
                                                    <span className='font-13 d-block' key={index}>{ditem.item_name}</span>
                                                ))}
                                                <div className='mt-3 mb-5'>
                                                    <span className='font-13 d-block text-info cursor-pointer'>
                                                        Trial (1 Day) - ${item.price_daily}
                                                    </span>
                                                    <span className='font-13 d-block text-info cursor-pointer'>
                                                        WEEKLY (5 Days) - ${item.price_weekly}
                                                    </span>
                                                    <span className='font-13 d-block text-info cursor-pointer'>
                                                        MONTHLY ( 20 Day) - ${item.price_monthly}
                                                    </span>
                                                </div>
                                            </div>
                                            <CButton
                                                className='fixed-button'
                                                color='success'
                                                onClick={() => handleAddPackage(item.id)}
                                            >
                                                <strong>ADD</strong>
                                            </CButton>
                                        </div>
                                    ))}
                                </div>
                            </div>
                            <h5 className='text-center'>Selected Package</h5>
                            <div>
                                {products.map((product) => (
                                    <React.Fragment key={product.id}>{product.content}</React.Fragment>
                                ))}
                            </div>
                            <div className='text-center'>
                                <CButton className='px-5' onClick={handlePackagesData}>Next</CButton>
                            </div>

                        </CCardBody>
                    </CCard>
                </CCol>
                <CCol></CCol>
            </CRow>
        </div>
    );
}

export default Customer;