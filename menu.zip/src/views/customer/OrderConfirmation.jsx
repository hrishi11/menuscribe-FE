import { CButton, CCol, CRow } from "@coreui/react";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getUserPackages, saveCustomerOrder } from '../../actions/customerReducer/CustomerActions'
import { useNavigate } from "react-router-dom";

const OrderConfirmation = () => {
    const { customerSelectedPackages } = useSelector(state => state.customer)
    const [customerPackages, setCustomerPackages] = useState();

    const dispatch = useDispatch();
    const navigate = useNavigate();

    useEffect(() => {
        const ids = customerSelectedPackages.map(item => item.id);
        const fetchData = async () => {
            try {
                const [userPackagesResponse] = await Promise.all([
                    dispatch(getUserPackages(ids))
                ]);
                setCustomerPackages(userPackagesResponse.data)
            } catch (error) {
                console.error("Error fetching packages:", error);
            }
        };

        fetchData();
        console.log(ids)
    }, [dispatch, customerSelectedPackages]);

    const handleConfirmOrder = async () => {
        const ids = customerSelectedPackages.map(item => item.id);
        await dispatch(saveCustomerOrder(ids))
       navigate('/payment-confirmation')
    }

    const calculateTotalPrice = () => {
        let totalPrice = 0;

        const rows = customerPackages.map((item) => {
            let price;

            switch (item.frequency) {
                case 'daily':
                    price = item.VendorPackage.price_daily;
                    break;
                case 'weekly':
                    price = item.VendorPackage.price_weekly;
                    break;
                case 'monthly':
                    price = item.VendorPackage.price_monthly;
                    break;
                default:
                    price = 0;
            }

            totalPrice += price;

            return (
                <tr key={item.id}>
                    <td>{`${item.VendorPackage.package_name} - ${item.frequency}`}</td>
                    {item.frequency === 'daily' && <td>{item.VendorPackage.price_daily}</td>}
                    {item.frequency === 'weekly' && <td>{item.VendorPackage.price_weekly}</td>}
                    {item.frequency === 'monthly' && <td>{item.VendorPackage.price_monthly}</td>}
                </tr>
            );
        });

        rows.push(
            <tr key="total">
                <td style={{ paddingTop: '100px' }}><strong>Total</strong></td>
                <td style={{ paddingTop: '100px' }}>{totalPrice}</td>
            </tr>
        );

        return rows;
    };

    return (
        <div className='mb-3 d-flex justify-content-center'>
            <div className='col-md-6 col-12 d-block box px-2 py-2'>
                <h1 className="h4 fw-bold text-info text-center">Confirm Your Order</h1>
                <p className="text-center">Confirm your order below and make payment to the vendor.</p>
                <CRow>
                    <CCol>
                        <h4 className="text-uppercase fw-bold h5">Order Summary</h4>
                        <table className="table borderless-table">
                            <tbody>
                                {customerPackages && calculateTotalPrice()}
                            </tbody>
                        </table>
                    </CCol>
                    <div className="text-center">
                        <CButton color="info" className="text-white px-5" onClick={handleConfirmOrder}>Confirm Order</CButton>
                    </div>
                </CRow>
            </div>
        </div >
    );
}

export default OrderConfirmation;