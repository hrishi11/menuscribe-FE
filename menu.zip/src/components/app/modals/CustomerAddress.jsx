import { CButton, CCol, CForm, CFormInput, CFormLabel, CFormSelect, CModal, CModalBody, CModalFooter, CModalHeader, CModalTitle, CRow } from "@coreui/react";
import { useEffect, useState } from "react";
import { useDispatch } from 'react-redux';
import { getCustomerAddress, updateCustomerAddress } from '../../../actions/customerReducer/CustomerActions'
import { getCities } from '../../../actions/vendorReducers/VendorActions'
import { Toast } from "../Toast";

const CustomerAddress = ({ showAddressModal, setShowAddressModal, setUpdateTrigger, customerId, addressId }) => {
    const [itemValidated, setItemValidated] = useState(false)
    const [formData, setFormData] = useState([]);
    const [cities, setCities] = useState();
    const dispatch = useDispatch();

    const handleFormData = (event) => {
        const { name, value } = event.target;
        setFormData((prevData) => ({
            ...prevData,
            [name]: value,
        }));
    };
    useEffect(() => {
        const fetchData = async () => {
            try {
                const [CitiesResponse, AddressResponse] = await Promise.all([
                    dispatch(getCities()),
                    addressId && addressId !== 0 && dispatch(getCustomerAddress(addressId)),
                ]);
                setCities(CitiesResponse.data);
                setFormData(addressId !== 0 ? AddressResponse.data : []);
                setFormData((prevData) => ({
                    ...prevData,
                    customer_id: customerId,
                }));
            } catch (error) {
                console.error("Error fetching address:", error);
            }
        };
        fetchData();
    }, [dispatch, addressId, customerId]);

    const handleCustomerAddress = async (event) => {
        event.preventDefault();
        const form = event.currentTarget
        if (form.checkValidity() === false) {
            event.stopPropagation()
            setItemValidated(true)
        } else {
            const response = await dispatch(updateCustomerAddress(formData));
            setShowAddressModal(false)
            if (response && response.success) {
                Toast({ message: 'Address updated successfully.', type: 'success' });
            }
            setUpdateTrigger((prev) => !prev);
        }
    }

    return (
        <CRow>
            <CModal
                visible={showAddressModal}
                onClose={() => setShowAddressModal(false)}
                aria-labelledby="LiveDemoExampleLabel"
            >
                <CModalHeader onClose={() => setShowAddressModal(false)}>
                    <CModalTitle id="LiveDemoExampleLabel">Add Address</CModalTitle>
                </CModalHeader>
                <CForm
                    className="row g-3 needs-validation"
                    noValidate
                    validated={itemValidated}
                    onSubmit={handleCustomerAddress}
                >
                    <CModalBody>
                        <CRow>
                            <CCol>
                                <CFormLabel className='font-12'>Address</CFormLabel>
                                <CFormInput
                                    className='simple-input'
                                    type="text"
                                    name="address"
                                    required
                                    onChange={handleFormData}
                                    value={formData.address}
                                />
                            </CCol>
                        </CRow>
                        <CRow>
                            <CCol>
                                <CFormLabel className='font-12'>Postal</CFormLabel>
                                <CFormInput
                                    className='simple-input'
                                    type="text"
                                    name="postal"
                                    required
                                    onChange={handleFormData}
                                    value={formData.postal}
                                />
                            </CCol>
                        </CRow>
                        <CRow>

                            <CCol>
                                <CFormLabel className='font-12'>City</CFormLabel>
                                <CFormSelect
                                    className='simple-input'
                                    type="text"
                                    name="city_id"
                                    required
                                    onChange={handleFormData}
                                    value={formData.city_id}
                                >
                                    <option value="">Select</option>
                                    {cities && cities.map((city) => (
                                        <option key={city.id} value={city.id}>{`${city.city} ${city.state}`}</option>
                                    ))}
                                </CFormSelect>
                            </CCol>
                        </CRow>
                        <CRow>
                            <CCol>
                                <CFormLabel className='font-12'>Delivery Instructions</CFormLabel>
                                <CFormInput
                                    className='simple-input'
                                    type="text"
                                    name="delivery_instructions"
                                    required
                                    onChange={handleFormData}
                                    value={formData.delivery_instructions}
                                />
                            </CCol>
                        </CRow>
                    </CModalBody>
                    <CModalFooter>
                        <CButton color="secondary" onClick={() => setShowAddressModal(false)}>
                            Close
                        </CButton>
                        <CButton type='submit' color="primary">Save changes</CButton>
                    </CModalFooter>
                </CForm>
            </CModal>
        </CRow>
    );
}

export default CustomerAddress;