import { toast } from 'react-toastify';

export const setTimeFormat = (date) => {
    const dateObject = new Date(date);
    return dateObject.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
}

export const getNextDatesOfWeek = (daysArray) => {  
    let currentDate = new Date();
    let nextDays = [];
    for (let i = 0; i < 30; i++) {
        if (nextDays.length >= 7) {
            continue;
        }
        const formattedDate = currentDate.toISOString().split('T')[0];
        const dayName = currentDate.toLocaleDateString('en-US', { weekday: 'long' });
        //console.log();
        if (daysArray.includes(dayName)) {
            nextDays.push({Date: formattedDate, Day: dayName})
        }
        currentDate.setDate(currentDate.getDate() + 1);
    }
    return nextDays;
}

export const formatDate = (dateString) => {
    const options = { day: 'numeric', month: 'short' };
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', options);
  }

export const getDateFromString = (inputString) => {
    // Create a new Date object using the input string
    const dateObject = new Date(inputString);

    // Extract the individual components of the date
    const year = dateObject.getFullYear();
    const month = String(dateObject.getMonth() + 1).padStart(2, '0'); // Months are zero-based
    const day = String(dateObject.getDate()).padStart(2, '0');

    // Assemble the date in the "YYYY-MM-DD" format
    const formattedDate = `${year}-${month}-${day}`;

    return formattedDate;
}

export const getCurrentDate = () => {
    // Create a new Date object for the current date
    const currentDate = new Date();

    // Extract the individual components of the date
    const year = currentDate.getFullYear();
    const month = String(currentDate.getMonth() + 1).padStart(2, '0'); // Months are zero-based
    const day = String(currentDate.getDate()).padStart(2, '0');

    // Assemble the date in the "YYYY-MM-DD" format
    const formattedDate = `${year}-${month}-${day}`;

    return formattedDate;
}

export const adjustData = (inputData) => {
    const resultObject = {};
    for (const key in inputData) {
        if (inputData.hasOwnProperty(key)) {
            const [property, id] = key.split('_');
            const parsedId = parseInt(id);
            if (!isNaN(parsedId)) {
                if (!resultObject.hasOwnProperty(parsedId)) {
                    resultObject[parsedId] = {};
                }
                resultObject[parsedId][property] = inputData[key];
            }
        }
    }

    const resultArray = Object.keys(resultObject).map(id => ({
        id: parseInt(id),
        ...resultObject[id]
    }));

    return resultArray;
}

export const formatTime = (timeString) => {
    const timeArray = timeString.split(':');
    const formattedTime = `${timeArray[0]}:${timeArray[1]}`;
    return formattedTime;
}

export const arrayBufferToBase64 = (buffer) => {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
};
export const scrollToTop = () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth',
    });
}