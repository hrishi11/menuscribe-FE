import React, { Component, Suspense } from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import ProtectedRoute from './ProtectedRoute';

import './scss/style.scss'

const loading = (
  <div className="pt-3 text-center">
    <div className="sk-spinner sk-spinner-pulse"></div>
  </div>
)

// Containers
const DefaultLayout = React.lazy(() => import('./layout/DefaultLayout'))

// Pages
const AdminLogin = React.lazy(() => import('./views/pages/login/Login'))
const ResetPassword = React.lazy(() => import('./views/pages/login/ResetPassword'))
const CustomerLogin = React.lazy(() => import('./views/customer/CustomerLogin'))
const Register = React.lazy(() => import('./views/pages/register/Register'))
const Page404 = React.lazy(() => import('./views/pages/page404/Page404'))
const Page500 = React.lazy(() => import('./views/pages/page500/Page500'))
const Customer = React.lazy(() => import('./views/customer/Customer'))
const CustomerSetting = React.lazy(() => import('./views/customer/CustomerSetting'))
const CustomerOnboard = React.lazy(() => import('./views/customer/CustomerOnboard'))
const CustomerPinVerify = React.lazy(() => import('./views/customer/CustomerPinVerify'))
const OrderConfirmation = React.lazy(() => import('./views/customer/OrderConfirmation'))
const PaymentConfirmation = React.lazy(() => import('./views/customer/PaymentConfirmation'))
const DashboardCustomer = React.lazy(() => import('./views/customer/DashboardCustomer'))


class App extends Component {
  render() {
    
    return (
      <BrowserRouter>
        <Suspense fallback={loading}>
          <Routes>
            <Route exact path="/login" name="Login Page" element={<CustomerLogin />} />
            <Route exact path="/admin-login" name="Login Page" element={<AdminLogin />} />
            <Route exact path="/reset-password" name="Login Page" element={<ResetPassword />} />
            <Route path="/customer-onboard/:id" element={<CustomerOnboard />} />
            <Route path="/customer-pin-verify/:id" element={<CustomerPinVerify />} />
            {/* <Route exact path="/register" name="Register Page" element={<Register />} /> */}
            
            <Route path="/customer-setting" element={<ProtectedRoute element={<CustomerSetting />} />} />
            <Route path="/customer" element={<ProtectedRoute element={<Customer />} />} />
            <Route path="/order-confirmation" element={<ProtectedRoute element={<OrderConfirmation />} />} />
            <Route path="/payment-confirmation" element={<ProtectedRoute element={<PaymentConfirmation />} />} />
            <Route path="/customer-dashboard" element={<ProtectedRoute element={<DashboardCustomer />} />} />
            {/* ... (other routes) */}

            {/* <ProtectedRoute path="/customer" name="Login Page" element={<Customer />} />
            <ProtectedRoute path="/customer-setting" name="Customer Setting" element={<CustomerSetting />} />
            <ProtectedRoute path="/order-confirmation" name="Order Confirmation" element={<OrderConfirmation />} />
            <ProtectedRoute path="/payment-confirmation" name="Payment Confirmation" element={<PaymentConfirmation />} />
            <ProtectedRoute path="/customer-dashboard" name="Customer Dashboard" element={<DashboardCustomer />} />
            <ProtectedRoute path="/404" name="Page 404" element={<Page404 />} />
            <ProtectedRoute path="/500" name="Page 500" element={<Page500 />} /> */}
            <Route path="*" name="Home" element={<ProtectedRoute element={<DefaultLayout />} />} />
          </Routes>
        </Suspense>
      </BrowserRouter>
    )
  }
}

export default App
